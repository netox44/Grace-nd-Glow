/* ===== GLOW & GRACE — script ===== */
(function () {
  'use strict';

  const CUR = '$'; // change to 'Rs. ' if you want rupees
  const U = (id, w = 900) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

  /* ---------- fallback if an image fails to load ---------- */
  const FALLBACK = 'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 500"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbd6e4"/><stop offset="1" stop-color="#f19ebd"/></linearGradient></defs><rect width="400" height="500" fill="url(#g)"/><text x="200" y="262" text-anchor="middle" font-family="Georgia,serif" font-size="34" font-style="italic" fill="#fff">Glow &amp; Grace</text></svg>'
  );
  document.addEventListener('error', (e) => {
    const t = e.target;
    if (t.tagName === 'IMG' && !t.dataset.fb) { t.dataset.fb = '1'; t.src = FALLBACK; }
  }, true);

  /* ---------- data ---------- */
  const IMG = {
    hero: '1522337360788-8b13dee7a37e',
    lips: '1583241475880-083f84372725',
    face: '1596462502278-27bfdc403348',
    eyes: '1512496015851-a90fb38ba796',
    skin: '1571781926291-c477ebfd024b',
    m1: '1494790108377-be9c29b29330',
    m2: '1531746020798-e6953c6e8e04',
    m3: '1438761681033-6461ffad8d80',
    m4: '1580489944761-15a19d654956',
    m5: '1515688594390-b649af70d282',
    m6: '1503236823255-94609f598e71',
    studio: '1522335789203-aabd1fc54bc9'
  };
  window.GG_IMG = IMG;
  window.GG_U = U;
  const GALLERY = [IMG.studio, IMG.m5, IMG.face, IMG.skin, IMG.m6, IMG.eyes];

  const PRODUCTS = [
    { id: 1, name: 'Velvet Rose Lipstick', cat: 'Lips', price: 24, old: 30, img: IMG.lips, badge: 'Bestseller', rating: 4.9, reviews: 812, desc: 'A creamy, blurred-edge lipstick with a soft matte finish. Pigment-rich, comfortable for eight hours and enriched with shea butter so lips never feel dry.', shades: [['Rosewood', '#b5475f'], ['Petal Pink', '#e58aa5'], ['Berry Bloom', '#8e2c52'], ['Nude Silk', '#c98c82']] },
    { id: 2, name: 'Silk Glow Foundation', cat: 'Face', price: 38, img: '1599305090598-fe179d501227', badge: 'New', rating: 4.8, reviews: 540, desc: 'Lightweight medium coverage that looks like skin, only better. Buildable, breathable and finished with a natural luminous glow.', shades: [['Porcelain', '#f3d7c6'], ['Sand', '#e2b998'], ['Honey', '#c88f64'], ['Mocha', '#8d5a3c'], ['Espresso', '#5b3524']] },
    { id: 3, name: 'Petal Blush Duo', cat: 'Face', price: 22, img: IMG.face, rating: 4.7, reviews: 366, desc: 'Two coordinating blush shades in a silky powder that melts into the cheeks. Wear one, or swirl both for a fresh flush.', shades: [['Peony', '#ef8fa8'], ['Coral Kiss', '#f1907a'], ['Mauve', '#b9677d']] },
    { id: 4, name: 'Dew Drop Hydrating Serum', cat: 'Skincare', price: 46, old: 56, img: '1620916566398-39f1143ab7be', badge: '-18%', rating: 4.9, reviews: 1204, desc: 'Hyaluronic acid and rose extract in a feather-light serum. Plumps, smooths and leaves a healthy dewy finish under makeup.', shades: [] },
    { id: 5, name: 'Cloud Cream Moisturizer', cat: 'Skincare', price: 34, img: '1586495777744-4413f21062fa', rating: 4.8, reviews: 689, desc: 'A whipped daily moisturizer with ceramides and vitamin E. Locks in hydration for 24 hours without feeling heavy.', shades: [] },
    { id: 6, name: 'Midnight Lash Mascara', cat: 'Eyes', price: 20, img: IMG.studio, badge: 'Bestseller', rating: 4.8, reviews: 934, desc: 'Length, lift and deep black volume in one stroke. Smudge-proof, flake-proof and gentle on sensitive eyes.', shades: [['Black', '#1c1115'], ['Brown', '#4a2c25']] },
    { id: 7, name: 'Rosewood Eyeshadow Palette', cat: 'Eyes', price: 42, img: '1487412947147-5cebf100ffc2', badge: 'New', rating: 4.9, reviews: 472, desc: 'Twelve rose, mauve and champagne shades in matte, satin and shimmer. Highly pigmented and easy to blend for day or night.', shades: [] },
    { id: 8, name: 'Glaze Lip Oil', cat: 'Lips', price: 18, img: '1598440947619-2c35fc9aa908', rating: 4.7, reviews: 623, desc: 'A non-sticky, high-shine lip oil that conditions as it glosses. Sheer tint with a juicy, plump look.', shades: [['Clear', '#f6d7de'], ['Cherry', '#d6405f'], ['Honey', '#d99a62']] },
    { id: 9, name: 'Radiance Highlighter', cat: 'Face', price: 28, img: '1625093742435-6fa192b6fb10', rating: 4.8, reviews: 351, desc: 'A finely milled powder with a satin-pearl glow. Catches light on cheekbones, brow bone and cupid\'s bow without glitter.', shades: [['Champagne', '#f2d9b5'], ['Rose Gold', '#e8b4a4']] },
    { id: 10, name: 'Rose Water Setting Mist', cat: 'Skincare', price: 19, img: '1556228720-195a672e8a03', rating: 4.6, reviews: 278, desc: 'A fine mist of rose water and aloe that refreshes skin and locks makeup in place all day.', shades: [] },
    { id: 11, name: 'Satin Nail Lacquer', cat: 'Nails', price: 14, img: '1604654894610-df63bc536371', rating: 4.6, reviews: 198, desc: 'Chip-resistant colour with a glossy, salon-style finish. Dries fast, free from the common nasties.', shades: [['Blush', '#f1b8c8'], ['Ruby', '#b3213f'], ['Ballet', '#f3d9d8']] },
    { id: 12, name: 'Blend & Sculpt Brush Set', cat: 'Tools', price: 52, old: 64, img: '1522338242992-e1a54906a8da', badge: 'Set of 8', rating: 4.9, reviews: 415, desc: 'Eight vegan-bristle brushes for face and eyes, in a rose-gold finish with a travel pouch. Soft, dense and made to last.', shades: [] }
  ];
  const byId = (id) => PRODUCTS.find((p) => p.id === +id);
  const money = (n) => CUR + n.toFixed(2).replace(/\.00$/, '');
  const stars = (r) => '★'.repeat(Math.round(r)) + '☆'.repeat(5 - Math.round(r));

  /* ---------- icons ---------- */
  const ICONS = {
    bag: '<path d="M6 7h12l1 13H5L6 7z"/><path d="M9 7a3 3 0 0 1 6 0"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    truck: '<path d="M3 6h11v10H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
    leaf: '<path d="M5 19c0-9 6-14 15-14 0 9-5 15-14 15"/><path d="M5 19c3-5 6-8 10-10"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m9 12 2 2 4-4"/>',
    sparkle: '<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
    gift: '<rect x="4" y="9" width="16" height="11"/><path d="M3 9h18V6H3zM12 6v14M12 6c-2-4-6-3-5 0M12 6c2-4 6-3 5 0"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    pin: '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14-4l-2 2M4 13a8 8 0 0 0 14 4l2-2M4 4v5h5M20 20v-5h-5"/>',
    star: '<path d="m12 3 2.7 5.8 6.3.7-4.7 4.3 1.3 6.2L12 17l-5.6 3 1.3-6.2L3 9.5l6.3-.7z"/>'
  };
  const icon = (n) => `<span class="i" aria-hidden="true"><svg viewBox="0 0 24 24">${ICONS[n] || ''}</svg></span>`;
  const paintIcons = (root = document) => root.querySelectorAll('[data-icon]').forEach((el) => { if (!el.dataset.done) { el.innerHTML = icon(el.dataset.icon); el.dataset.done = 1; } });

  /* ---------- storage helpers ---------- */
  const store = {
    get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };
  let cart = store.get('gg_cart', []);
  let wish = store.get('gg_wish', []);
  let promo = store.get('gg_promo', '');

  /* ---------- layout ---------- */
  const page = document.body.dataset.page || 'home';
  const nav = [['index.html', 'Home', 'home'], ['shop.html', 'Shop', 'shop'], ['about.html', 'Our story', 'about'], ['contact.html', 'Contact', 'contact']];

  function buildLayout() {
    const header = `
      <div class="announce">Free shipping on orders over <b>$50</b> &nbsp;•&nbsp; Use code <b>GLOW15</b> for 15% off</div>
      <header class="site-header"><div class="container nav-wrap">
        <a class="logo" href="index.html" aria-label="Glow &amp; Grace home"><span>Glow</span><em>&amp;</em><span>Grace</span></a>
        <nav class="nav" id="nav" aria-label="Main">${nav.map((n) => `<a href="${n[0]}" class="${page === n[2] ? 'active' : ''}">${n[1]}</a>`).join('')}</nav>
        <div class="head-actions">
          <a class="icon-btn" href="shop.html#search" aria-label="Search">${icon('search')}</a>
          <button class="icon-btn" id="wishBtn" aria-label="Wishlist">${icon('heart')}<span class="count" id="wishCount">0</span></button>
          <button class="icon-btn" id="cartBtn" aria-label="Open cart">${icon('bag')}<span class="count" id="cartCount">0</span></button>
          <button class="icon-btn burger" id="burger" aria-label="Menu" aria-expanded="false">${icon('menu')}</button>
        </div>
      </div></header>`;

    const footer = `
      <footer class="footer"><div class="container">
        <div class="foot-grid">
          <div><a class="logo" href="index.html"><span>Glow</span><em>&amp;</em><span>Grace</span></a>
            <p>A modern cosmetics house for elegant everyday beauty. Cruelty-free, vegan-friendly formulas made to make you feel like yourself, only more radiant.</p>
            <div class="social"><a href="#" aria-label="Instagram">Ig</a><a href="#" aria-label="Facebook">Fb</a><a href="#" aria-label="TikTok">Tk</a><a href="#" aria-label="Pinterest">Pn</a></div></div>
          <div><h4>Shop</h4><ul><li><a href="shop.html?cat=Lips">Lips</a></li><li><a href="shop.html?cat=Face">Face</a></li><li><a href="shop.html?cat=Eyes">Eyes</a></li><li><a href="shop.html?cat=Skincare">Skincare</a></li></ul></div>
          <div><h4>Company</h4><ul><li><a href="about.html">Our story</a></li><li><a href="contact.html">Contact us</a></li><li><a href="contact.html#faq">FAQs</a></li><li><a href="shop.html">All products</a></li></ul></div>
          <div><h4>Stay in touch</h4><p>hello@glowandgrace.com<br>Mon–Sat, 10am – 7pm</p><p style="margin-top:.8rem">Secure payments • Easy 30-day returns</p></div>
        </div>
        <div class="foot-bottom"><span>© ${new Date().getFullYear()} Glow &amp; Grace. All rights reserved.</span><span>Designed with love for beautiful skin.</span></div>
      </div></footer>
      <div class="overlay" id="overlay"></div>
      <aside class="drawer" id="drawer" aria-label="Shopping cart" aria-hidden="true">
        <div class="drawer-head"><h3>Your bag</h3><button class="icon-btn" id="closeCart" aria-label="Close cart">${icon('close')}</button></div>
        <div class="drawer-body" id="cartBody"></div>
        <div class="drawer-foot" id="cartFoot"></div>
      </aside>
      <div class="toast" id="toast" role="status"></div>`;

    document.body.insertAdjacentHTML('afterbegin', header);
    document.body.insertAdjacentHTML('beforeend', footer);
  }

  /* ---------- toast ---------- */
  let tt;
  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.classList.add('on');
    clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2200);
  }

  /* ---------- cart ---------- */
  const saveCart = () => { store.set('gg_cart', cart); renderCart(); };
  function addToCart(id, shade = '', qty = 1) {
    const found = cart.find((c) => c.id === id && c.shade === shade);
    if (found) found.qty += qty; else cart.push({ id, shade, qty });
    saveCart(); openCart();
  }
  function renderCart() {
    const body = document.getElementById('cartBody');
    const foot = document.getElementById('cartFoot');
    const n = cart.reduce((a, c) => a + c.qty, 0);
    document.getElementById('cartCount').textContent = n;
    document.getElementById('cartCount').style.display = n ? 'grid' : 'none';
    if (!cart.length) {
      body.innerHTML = '<div class="cart-empty"><p>Your bag is empty.</p><p style="margin:.4rem 0 1.2rem">Find something you will love.</p><a class="btn btn-primary" href="shop.html">Shop all products</a></div>';
      foot.style.display = 'none'; return;
    }
    foot.style.display = '';
    body.innerHTML = cart.map((c, i) => {
      const p = byId(c.id);
      return `<div class="line"><img src="${U(p.img, 300)}" alt="${p.name}" loading="lazy">
        <div><b>${p.name}</b><small>${c.shade || p.cat}</small><br>
        <div class="mini-qty"><button data-q="-1" data-i="${i}" aria-label="Decrease">−</button><span>${c.qty}</span><button data-q="1" data-i="${i}" aria-label="Increase">+</button></div></div>
        <div style="text-align:right"><div>${money(p.price * c.qty)}</div><button class="rm" data-rm="${i}">Remove</button></div></div>`;
    }).join('');
    const sub = cart.reduce((a, c) => a + byId(c.id).price * c.qty, 0);
    const disc = promo === 'GLOW15' ? sub * 0.15 : 0;
    const ship = sub - disc >= 50 ? 0 : 4.99;
    foot.innerHTML = `
      <div class="promo"><input id="promoIn" placeholder="Promo code" value="${promo}" aria-label="Promo code"><button class="btn btn-ghost" id="promoBtn" style="padding:.5rem 1.1rem">Apply</button></div>
      <div class="sum"><span>Subtotal</span><span>${money(sub)}</span></div>
      ${disc ? `<div class="sum"><span>Code GLOW15</span><span>−${money(disc)}</span></div>` : ''}
      <div class="sum"><span>Shipping</span><span>${ship ? money(ship) : 'Free'}</span></div>
      <div class="sum total"><span>Total</span><span>${money(sub - disc + ship)}</span></div>
      <button class="btn btn-primary btn-block" id="checkout">Checkout</button>`;
  }
  const openCart = () => { document.getElementById('drawer').classList.add('on'); document.getElementById('overlay').classList.add('on'); document.getElementById('drawer').setAttribute('aria-hidden', 'false'); };
  const closeCart = () => { document.getElementById('drawer').classList.remove('on'); document.getElementById('overlay').classList.remove('on'); document.getElementById('drawer').setAttribute('aria-hidden', 'true'); };

  /* ---------- wishlist ---------- */
  function toggleWish(id) {
    wish = wish.includes(id) ? wish.filter((w) => w !== id) : [...wish, id];
    store.set('gg_wish', wish); syncWish();
    toast(wish.includes(id) ? 'Saved to your wishlist' : 'Removed from wishlist');
  }
  function syncWish() {
    const c = document.getElementById('wishCount');
    c.textContent = wish.length; c.style.display = wish.length ? 'grid' : 'none';
    document.querySelectorAll('.wish').forEach((b) => b.classList.toggle('on', wish.includes(+b.dataset.wish)));
  }

  /* ---------- product card ---------- */
  function card(p) {
    return `<article class="card">
      <div class="card-img">
        ${p.badge ? `<span class="badge ${p.badge.startsWith('-') ? 'dark' : ''}">${p.badge}</span>` : ''}
        <button class="wish" data-wish="${p.id}" aria-label="Save ${p.name} to wishlist">${icon('heart')}</button>
        <a href="product.html?id=${p.id}" aria-label="${p.name}" style="display:block;height:100%"><img src="${U(p.img, 700)}" alt="${p.name}" loading="lazy"></a>
        <button class="quick" data-add="${p.id}">Add to bag</button>
      </div>
      <div class="card-body"><small>${p.cat}</small>
        <h3><a href="product.html?id=${p.id}">${p.name}</a></h3>
        <div class="rate">${stars(p.rating)}<span>(${p.reviews})</span></div>
        <div class="price">${money(p.price)}${p.old ? `<s>${money(p.old)}</s>` : ''}</div></div>
    </article>`;
  }

  /* ---------- page: home ---------- */
  function initHome() {
    const el = document.getElementById('bestsellers');
    if (el) el.innerHTML = PRODUCTS.slice(0, 8).map(card).join('');
  }

  /* ---------- page: shop ---------- */
  function initShop() {
    const grid = document.getElementById('shopGrid');
    if (!grid) return;
    const cats = ['All', 'Lips', 'Face', 'Eyes', 'Skincare', 'Nails', 'Tools'];
    const params = new URLSearchParams(location.search);
    let cat = cats.includes(params.get('cat')) ? params.get('cat') : 'All';
    let q = '', sort = 'featured';
    const chips = document.getElementById('chips');
    const render = () => {
      chips.innerHTML = cats.map((c) => `<button class="chip ${c === cat ? 'active' : ''}" data-cat="${c}">${c}</button>`).join('');
      let list = PRODUCTS.filter((p) => (cat === 'All' || p.cat === cat) && (p.name + p.cat + p.desc).toLowerCase().includes(q));
      if (sort === 'low') list.sort((a, b) => a.price - b.price);
      if (sort === 'high') list.sort((a, b) => b.price - a.price);
      if (sort === 'rated') list.sort((a, b) => b.rating - a.rating);
      document.getElementById('resultCount').textContent = `${list.length} product${list.length === 1 ? '' : 's'}`;
      grid.innerHTML = list.length ? list.map(card).join('') : '<div class="empty"><h3>Nothing matched that search</h3><p>Try a different word or choose another category.</p></div>';
      syncWish();
    };
    chips.addEventListener('click', (e) => { const b = e.target.closest('[data-cat]'); if (b) { cat = b.dataset.cat; render(); } });
    const search = document.getElementById('search');
    search.addEventListener('input', () => { q = search.value.trim().toLowerCase(); render(); });
    document.getElementById('sort').addEventListener('change', (e) => { sort = e.target.value; render(); });
    if (location.hash === '#search') search.focus();
    render();
  }

  /* ---------- page: product ---------- */
  function initProduct() {
    const root = document.getElementById('productRoot');
    if (!root) return;
    const p = byId(new URLSearchParams(location.search).get('id')) || PRODUCTS[0];
    document.title = `${p.name} | Glow & Grace`;
    const thumbs = [p.img, GALLERY[p.id % 6], GALLERY[(p.id + 2) % 6], GALLERY[(p.id + 4) % 6]];
    let shade = p.shades[0] ? p.shades[0][0] : '', qty = 1;
    root.innerHTML = `
      <div class="gallery"><div class="main"><img id="mainImg" src="${U(thumbs[0], 1000)}" alt="${p.name}"></div>
        <div class="thumbs">${thumbs.map((t, i) => `<button class="${i ? '' : 'on'}" data-t="${t}" aria-label="View image ${i + 1}"><img src="${U(t, 300)}" alt=""></button>`).join('')}</div></div>
      <div class="pd-info">
        <div class="crumbs"><a href="index.html">Home</a> / <a href="shop.html?cat=${p.cat}">${p.cat}</a> / ${p.name}</div>
        <h1>${p.name}</h1>
        <div class="rate">${stars(p.rating)}<span>${p.rating} • ${p.reviews} reviews</span></div>
        <div class="pd-price">${money(p.price)}${p.old ? `<s>${money(p.old)}</s>` : ''}</div>
        <p class="pd-desc">${p.desc}</p>
        ${p.shades.length ? `<div class="opt-label">Shade: <span id="shadeName">${shade}</span></div><div class="shades">${p.shades.map((s, i) => `<button class="shade ${i ? '' : 'on'}" data-shade="${s[0]}" style="background:${s[1]}" aria-label="${s[0]}"></button>`).join('')}</div>` : ''}
        <div class="buy">
          <div class="qty"><button id="qm" aria-label="Decrease quantity">−</button><span id="qv">1</span><button id="qp" aria-label="Increase quantity">+</button></div>
          <button class="btn btn-primary" id="addBtn" style="flex:1;min-width:180px">Add to bag</button>
          <button class="icon-btn wish" data-wish="${p.id}" aria-label="Wishlist" style="border:1.5px solid var(--line);width:50px;height:50px;position:static">${icon('heart')}</button>
        </div>
        <ul class="perks"><li>${icon('truck')} Free shipping over $50</li><li>${icon('refresh')} 30-day easy returns</li><li>${icon('leaf')} Cruelty-free &amp; vegan-friendly</li></ul>
      </div>`;
    document.getElementById('tabsRoot').innerHTML = `
      <div class="tab-btns"><button class="on" data-tab="0">Details</button><button data-tab="1">Ingredients</button><button data-tab="2">How to use</button></div>
      <div class="tab-panel on"><p>${p.desc} Dermatologically tested, free from parabens and mineral oil, and packaged in recyclable materials.</p></div>
      <div class="tab-panel"><p>Aqua, Glycerin, Rosa Damascena Flower Water, Squalane, Shea Butter, Tocopherol (Vitamin E), Hyaluronic Acid, Natural Pigments. Full ingredient list is printed on the box.</p></div>
      <div class="tab-panel"><p>Apply to clean skin. Start with a small amount and build up to your preferred intensity. Blend with fingertips or a soft brush. Reapply through the day as needed.</p></div>`;
    document.getElementById('related').innerHTML = PRODUCTS.filter((x) => x.id !== p.id && x.cat === p.cat).concat(PRODUCTS.filter((x) => x.id !== p.id && x.cat !== p.cat)).slice(0, 4).map(card).join('');

    root.addEventListener('click', (e) => {
      const t = e.target.closest('[data-t]');
      if (t) { document.getElementById('mainImg').src = U(t.dataset.t, 1000); root.querySelectorAll('.thumbs button').forEach((b) => b.classList.toggle('on', b === t)); }
      const s = e.target.closest('[data-shade]');
      if (s) { shade = s.dataset.shade; document.getElementById('shadeName').textContent = shade; root.querySelectorAll('.shade').forEach((b) => b.classList.toggle('on', b === s)); }
    });
    document.getElementById('qm').onclick = () => { qty = Math.max(1, qty - 1); document.getElementById('qv').textContent = qty; };
    document.getElementById('qp').onclick = () => { qty = Math.min(10, qty + 1); document.getElementById('qv').textContent = qty; };
    document.getElementById('addBtn').onclick = () => addToCart(p.id, shade, qty);
    document.getElementById('tabsRoot').addEventListener('click', (e) => {
      const b = e.target.closest('[data-tab]'); if (!b) return;
      const panels = document.querySelectorAll('.tab-panel');
      document.querySelectorAll('.tab-btns button').forEach((x, i) => { x.classList.toggle('on', x === b); panels[i].classList.toggle('on', x === b); });
    });
  }

  /* ---------- forms ---------- */
  function initForms() {
    const news = document.getElementById('newsForm');
    if (news) news.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = news.querySelector('input').value.trim();
      const msg = document.getElementById('newsMsg');
      if (!/^\S+@\S+\.\S+$/.test(v)) { msg.textContent = 'Please enter a valid email address.'; return; }
      msg.textContent = 'Welcome to the glow! Your code GLOW15 is ready to use.'; news.reset();
    });
    const cf = document.getElementById('contactForm');
    if (cf) cf.addEventListener('submit', (e) => {
      e.preventDefault();
      let ok = true;
      cf.querySelectorAll('[required]').forEach((f) => {
        const bad = !f.value.trim() || (f.type === 'email' && !/^\S+@\S+\.\S+$/.test(f.value));
        f.classList.toggle('err', bad); if (bad) ok = false;
      });
      const msg = document.getElementById('formMsg');
      if (!ok) { msg.textContent = 'Please fill in the highlighted fields.'; return; }
      msg.textContent = 'Thank you! Your message is on its way. We usually reply within one working day.';
      cf.reset();
    });
  }

  /* ---------- global events ---------- */
  function bindGlobal() {
    document.getElementById('cartBtn').onclick = openCart;
    document.getElementById('closeCart').onclick = closeCart;
    document.getElementById('overlay').onclick = closeCart;
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeCart(); });
    document.getElementById('wishBtn').onclick = () => toast(wish.length ? `You have ${wish.length} saved item${wish.length > 1 ? 's' : ''}` : 'Tap the heart on any product to save it');
    const burger = document.getElementById('burger');
    burger.onclick = () => { const o = document.getElementById('nav').classList.toggle('open'); burger.setAttribute('aria-expanded', o); };

    document.addEventListener('click', (e) => {
      const add = e.target.closest('[data-add]');
      if (add) { const p = byId(add.dataset.add); addToCart(p.id, p.shades[0] ? p.shades[0][0] : ''); return; }
      const w = e.target.closest('[data-wish]');
      if (w) { toggleWish(+w.dataset.wish); return; }
      const q = e.target.closest('[data-q]');
      if (q) { const i = +q.dataset.i; cart[i].qty += +q.dataset.q; if (cart[i].qty < 1) cart.splice(i, 1); saveCart(); return; }
      const rm = e.target.closest('[data-rm]');
      if (rm) { cart.splice(+rm.dataset.rm, 1); saveCart(); return; }
      if (e.target.id === 'promoBtn') {
        const v = document.getElementById('promoIn').value.trim().toUpperCase();
        if (v === 'GLOW15') { promo = v; store.set('gg_promo', v); toast('15% off applied'); } else { promo = ''; store.set('gg_promo', ''); toast('That code is not valid'); }
        renderCart(); return;
      }
      if (e.target.id === 'checkout') { toast('This is a demo store: checkout is not connected'); }
    });
  }

  /* ---------- boot ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    buildLayout();
    paintIcons();
    bindGlobal();
    renderCart();
    initHome(); initShop(); initProduct(); initForms();
    syncWish();
    paintIcons();
  });
})();
